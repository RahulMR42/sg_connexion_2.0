package com.ashu;

public class Candidate implements Comparable<Candidate>{
	
	String name;
	int no_of_yrs_exp;
	String location;
	String skillSet;
	
		
	public Candidate(String name, int no_of_yrs_exp, String location, String skillSet) {
		super();
		this.name = name;
		this.no_of_yrs_exp = no_of_yrs_exp;
		this.location = location;
		this.skillSet = skillSet;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + no_of_yrs_exp;
		result = prime * result + ((skillSet == null) ? 0 : skillSet.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Candidate other = (Candidate) obj;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (no_of_yrs_exp != other.no_of_yrs_exp)
			return false;
		if (skillSet == null) {
			if (other.skillSet != null)
				return false;
		} else if (!skillSet.equals(other.skillSet))
			return false;
		return true;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getNo_of_yrs_exp() {
		return no_of_yrs_exp;
	}


	public void setNo_of_yrs_exp(int no_of_yrs_exp) {
		this.no_of_yrs_exp = no_of_yrs_exp;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getSkillSet() {
		return skillSet;
	}


	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}


	@Override
	public int compareTo(Candidate cand) {
		if (no_of_yrs_exp ==cand.no_of_yrs_exp){
			return 0;
		}else if(no_of_yrs_exp > cand.no_of_yrs_exp)
			return 1;
		else
			return -1;
	}
	
}
