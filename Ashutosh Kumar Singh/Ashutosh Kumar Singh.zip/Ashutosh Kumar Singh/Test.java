package com.ashu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Candidate cand1 = new Candidate("Ram", 2, "Bangalore", "Frontend");
		Candidate cand2 = new Candidate("Mohan", 3, "Hyd", "Backend");
		List<Candidate> candList = new ArrayList<Candidate>();
		
		candList.add(cand1);
		candList.add(cand2);
		//Later on enter all name to DB or file.
		
		for (Candidate cand : candList)
			System.out.println(cand);
		Collections.sort(candList);
		//Print sorted List
		//We can print the LIst based on all the fields but we are showing here an example
		//to sort on basis of exprerince 
		for (Candidate cand : candList)
			System.out.println(cand);
		GetCandidate getcand = new GetCandidate();
		List<Candidate> candonbasisofExp = getcand.returnCandidatebyExp(candList, 2);
		List<Candidate> candonbasisofLoc = getcand.returnCandidatebyLOcation(candList, "Bangalore");
		
		System.out.println("on basis of experience");
		for(Candidate cand :candonbasisofExp ){
			System.out.println(cand);
		}
		
		System.out.println("on basis of Location");
		for(Candidate cand :candonbasisofLoc ){
			System.out.println(cand);
		}
		
	}
	
	
}
