Name:-Ashutosh Kumar Singh
Mobile no:-9986828987
email:-call2ashutosh@gmail.com

I have created "Candidate" Class as User framework.
"GetCandidate" class has all API for get candidate on basis of location and expertise
Third one is "Test" class to test the API