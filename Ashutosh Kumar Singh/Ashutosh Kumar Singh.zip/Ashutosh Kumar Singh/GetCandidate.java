package com.ashu;

import java.util.ArrayList;
import java.util.List;

public class GetCandidate {
	public List<Candidate> returnCandidatebyLOcation(List<Candidate> candList, String loc){
		List<Candidate> retList = new ArrayList<Candidate>();
		for (Candidate cand:candList ){
			if(loc.equals(cand.location))
				retList.add(cand);
		}
		return retList;
	}
	
	public List<Candidate> returnCandidatebyExp(List<Candidate> candList, int exp){
		List<Candidate> retList = new ArrayList<Candidate>();
		for (Candidate cand:candList ){
			if(exp == cand.no_of_yrs_exp)
				retList.add(cand);
		}
		return retList;
	}
}
